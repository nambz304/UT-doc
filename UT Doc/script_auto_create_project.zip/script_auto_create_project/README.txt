[Usage]: Automate making project Cantata
[How to use]:
	Step1: Copy list source C you want to make project Cantata
	Step2: Double click file <main.sh>
	Step3: Enjoy