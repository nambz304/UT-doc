#!/bin/bash

for f in `ls ./Source | grep '\.c$'`
do
  echo -e "\033[32m\033[1mCREATE project: $f"
  ./auto_create_Canta_project.sh ./Source/$f

done

echo -e "\033[32m\033[1mPlease get your OUTPUT at link: `pwd`/OUTPUT"

echo -e "\n\033[0;35m\033[1mPROGRAM will exist in 5s"

sleep 3s

