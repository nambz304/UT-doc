/******************************************************************************/
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/******************************************************************************/

#include "Std_Types.h"

#include "rba_BldrHsm.h"

#include "rba_BldrCmp_Cfg_SecFlash.h"
#include "ecy_hsm_service_misc.h"
#include "ecy_hsm_proxy.h"
#include "ecy_hsm_host_proxy.h"
#include "rba_BldrCmp_LogBlkHdl_BldrCmp.h"
#include "RBLCF_Hexblocks_Structs_Signature.h"
#include "rba_BldrBCLSigChk_HexFileInfo.h"


#if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE)

#include ecy_hsm_(csai.h)
#include ecy_hsm_(csai_keys.h)
#include ecy_hsm_(csai_secflash.h)

#if (   (RBA_BLDRHSM_HOSTREPROG == RBA_BLDRHSM_ENABLE)\
     || (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)\
     || (RBA_BLDRHSM_SECBOOT == RBA_BLDRHSM_ENABLE) )

static ecy_hsm_Csai_(JobHandleT) secFlashJob = ecy_hsm_CSAI_(INVALID_JOB_HANDLE_VALUE);

#if (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)
static boolean hsmReprogActive_b = FALSE;

boolean rba_BldrHsm_IsHsmReprogActive(void)
{
 return hsmReprogActive_b;
}

#endif


/**
 * This function does CSAI job handling for CSAI_SecFlash_Init
 * It will cancel old jobs, before intialization of hashing in order to clean hash buffer.

 *
 * return value:
 * E_OK: Data processed successfully.
 * E_NOT_OK: Failure occured
 * E_PENDING: Processing not finished. Call again.
 */

Std_ReturnType rba_BldrHsm_SecFlashInit(uint32 startAddress_u32, uint32 length_u32)
{
    /* First secFlashInit will switch HSM into bootloadermode. No cancel required for intial call */
    static rba_BldrHsm_SecFlash_StateMachine_tst rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_Init;
    static rba_BldrHsm_SecFlash_StateMachine_tst stateWhichTriggeredPolling_st = rba_BldrHsm_SecFlash_Init;

    ecy_hsm_Csai_(SessionHandleT) secFlashSession = ecy_hsm_CSAI_(INVALID_SESSION_HANDLE_VALUE);
    Std_ReturnType retValue = E_NOT_OK;
    ecy_hsm_Csai_(ErrorT) csaiResult = ecy_hsm_CSAI_(ERR_FLAG_ERROR);

    switch (rba_BldrHsm_SecFlashInit_StateMachine_st)
    {
        case rba_BldrHsm_SecFlash_CancelOldJob:
        {

            /* Programming sequence might be interupted due to an error. Tester will restart programming seqeunce  without an ECU reset.
             * Depending on the point of interruption in programming sequence, CSAI_SecFlash_Update might have been called already.
             * In case of SecBoot hashing has started, in case of HSM reprog writing to HSM code flash was started.
             * In order to put HSM into a defined state and clean up buffers and operation, a CSAI_SecFlash_Cancel need to be called.
             * Actually this is ony required in case of HSM reprog, but in future this might be relevant also for SecBoot usecase.
             *
             * CSAI_SecFlash_Cancel will be called before every CSAI_SecFlash_Init. There are two exceptions.
             * - Initial CSAI_SecFlash_Init call after ECU reset
             *      This will initiate session for SecFlash servcies and put HSM into bootloader mode.
             *      Without this session a cancel is not possible and not required, because no job is running.
             * - Between first and second CSAI_SecFlash_Init of a HSM reprog sequence
             *      For HSM reprog first CSAI_SecFlash_Init (caused by Erase Memory) will trigger erase of HSM code flash.
             *      CSAI_SecFlash_Cancel before second CSAI_SecFlash_Init (caused by Request downlaod) should be avoided,
             *      because erasing would be unecessary interrupted and needs to be restarted with second CSAI_SecFlash_Init.
             */
            if (ecy_hsm_Csai_(SecFlash_Cancel(secFlashJob)) == ecy_hsm_CSAI_(SUCCESS))
            {
                    /* Call succeeded. Operation is pending on HSM. Result needs to be polled via ecy_hsm_Csai_PollHandle */
                    rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_PollHandle;

                    /* Indicate, which state triggered polling state */
                    stateWhichTriggeredPolling_st = rba_BldrHsm_SecFlash_CancelOldJob;

                    /* Signal calling function that another activation is required */
                    retValue = E_PENDING;
            }
            else
            {
                /* HSM failure */
                retValue = E_NOT_OK;
            }

            break;
        }

        case rba_BldrHsm_SecFlash_Init:
        {
            /* Get active secflash session from session manager */
            secFlashSession = rba_BldrHsm_GetSession(rba_BldrHsm_SessionType_RB);

            /* If session was successfully opened (session handle is not invalid) */
            if (secFlashSession != ecy_hsm_CSAI_(INVALID_SESSION_HANDLE_VALUE))
            {
            #if (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)
                /* Check if address range is part of HSM code flash */
                hsmReprogActive_b = rba_BldrHsm_Cfg_IsRangePartOfHsmCodeFlash(startAddress_u32,length_u32);

                if (hsmReprogActive_b)
                {
                    csaiResult = ecy_hsm_Csai_(SecFlash_Init(secFlashSession, ecy_hsm_CSAI_(PRIO_LOW), ecy_hsm_CSAI_(SIG_NONE), (uint8 const *)startAddress_u32, length_u32, ecy_hsm_CSAI_(SECFLASH_OPT_NONE), RBA_BLDRHSM_TIMEOUT_MS_SWITCH_TO_RAM_MODE, &secFlashJob)); /* PRQA S 306 */
                }
                else
            #endif
                {
                    csaiResult = ecy_hsm_Csai_(SecFlash_Init(secFlashSession, ecy_hsm_CSAI_(PRIO_LOW), ecy_hsm_CSAI_(RSA_SSA_PSS_SHA256), (uint8 const *)startAddress_u32, length_u32, ecy_hsm_CSAI_(SECFLASH_OPT_NONE), RBA_BLDRHSM_TIMEOUT_MS_SWITCH_TO_RAM_MODE, &secFlashJob));/* PRQA S 306 */
                }

                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
 					/* Call succeeded. Operation is pending on HSM. Result needs to be polled via ecy_hsm_Csai_PollHandle */
                    rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_PollHandle;

                    /* Indicate, which state triggered polling state */
                    stateWhichTriggeredPolling_st = rba_BldrHsm_SecFlash_Init;

                    /* Signal calling function that another activation is required */
                    retValue = E_PENDING;
                }
                else
                {
                    /* HSM failure */

                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* Session couldn't be opened. No free ports available. Session handle will be invalid */
                retValue = E_NOT_OK;
            }

            break;
        }

        case rba_BldrHsm_SecFlash_PollHandle:
        {
            /* Request job result of hash framework initialization */
            csaiResult = ecy_hsm_Csai_(PollHandle(secFlashJob));

            /* If result is available */
            if (csaiResult != ecy_hsm_CSAI_(FC_PENDING))
            {
                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
                    /* Calculate next state based on predecessor state */
                    if (stateWhichTriggeredPolling_st == rba_BldrHsm_SecFlash_CancelOldJob)
                    {
                        rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_Init;
                        retValue = E_PENDING;
                    }
                    else
                    {
                        retValue = E_OK;
                    }
                }
                else
                {
                    /* HSM failure */
                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* Signal calling function that another activation is required */
                retValue = E_PENDING;
            }

            break;
        }

        default:
        {
            /* Unknown state */
            retValue = E_NOT_OK;

            break;
        }
    }

    if (retValue != E_PENDING)
    {
        /* Initialize statemachine */
        rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_CancelOldJob;
        stateWhichTriggeredPolling_st = rba_BldrHsm_SecFlash_CancelOldJob;

        #if (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)

            /* In case of hsm reprog do not cancel old jobs !
             * For HSM reprog first CSAI_SecFlash_Init (caused by Erase Memory) will trigger erase of HSM code flash.
             * CSAI_SecFlash_Cancel before second CSAI_SecFlash_Init (caused by Request downlaod) should be avoided,
             * because erasing would be unecessary interrupted and needs to be restarted with second CSAI_SecFlash_Init.
             * */
            if ((hsmReprogActive_b == TRUE) && (retValue == E_OK))
            {
                rba_BldrHsm_SecFlashInit_StateMachine_st = rba_BldrHsm_SecFlash_Init;
                stateWhichTriggeredPolling_st = rba_BldrHsm_SecFlash_Init;
            }

        #endif
    }

    return retValue;
}

#if (   (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)\
     || (RBA_BLDRHSM_SECBOOT == RBA_BLDRHSM_ENABLE) )
/**
 * This function does CSAI job handling for CSAI_SecFlash_Update
 * It will read data from memory and slice it into chunks of configurable size.
 *
 * return value:
 * E_OK: Data processed successfully.
 * E_NOT_OK: Failure occured
 * E_PENDING: Processing not finished. Call again.
 */
Std_ReturnType rba_BldrHsm_SecFlashUpdate(uint32 dataStartAddress_ui32, const uint8 * Source_pcu8,uint32 dataLength_ui32)
{
    /* This is an example implementation using GUAM-SIM as crypto system.
     * Used API for communication to crypto system is CSAI.
     * CSAI-API will also be used for communication with HSM on ECUs.
     *
     * CMP will provide pointer to variable sized data block. Might be a complete segment.
     * This function split the block into chunks of RBA_BLDRHSM_HASH_ON_THE_FLY_BUFFER.
     * */

    static rba_BldrHsm_SecFlash_StateMachine_tst rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_Init;

    __attribute__(( aligned(16))) static uint8 buffer_pui8[RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER];
    static uint32 actualLength_ui32;
    static uint32 actualPos_rom_ui32;
    static uint32 actualPos_ram_ui32;

    Std_ReturnType retValue = E_NOT_OK;

    switch (rba_BldrHsm_SecFlashUpdate_StateMachine_st)
    {
        case rba_BldrHsm_SecFlash_Init:
        {
            /* Reset static variables to default values */
            actualLength_ui32 = 0;
            actualPos_rom_ui32 = 0;
            actualPos_ram_ui32 = 0;

            /* Limit length for hashing to RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER value */
            if (dataLength_ui32 > RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER)
            {
                actualLength_ui32 = RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER;
            }
            else
            {
                actualLength_ui32 = dataLength_ui32;
            }

            /* Save actual position */
            actualPos_ram_ui32 = (uint32)Source_pcu8;
            actualPos_rom_ui32 = dataStartAddress_ui32;

            /* Goto next state */
            rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_PrepareBuffer;

            /* Signal calling function that another activation is required */
            retValue = E_PENDING;

            break;
        }

        case rba_BldrHsm_SecFlash_PrepareBuffer:
        {
            /* Call project specifc read memory function */
            retValue = rba_BldrHsm_Cfg_ReadMemory(actualPos_ram_ui32, buffer_pui8, actualLength_ui32);

            if (retValue == E_OK)
            {
                /* Data available in buffer. Call secflash update in next state */
                rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_Update;

                /* Signal calling function that another activation is required */
                retValue = E_PENDING;
            }

            break;
        }

        case rba_BldrHsm_SecFlash_Update:
        {
            /* Provide new chunk of data for SecFlash generation, check result and branch accordingly */
            if (ecy_hsm_Csai_(SecFlash_Update(secFlashJob, buffer_pui8, actualLength_ui32)) == ecy_hsm_CSAI_(SUCCESS))
            {
                rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_PollHandle;

                /* Signal calling function that another activation is required */
                retValue = E_PENDING;
            }
            else
            {
                retValue = E_NOT_OK;
            }

            break;
        }

        case rba_BldrHsm_SecFlash_PollHandle:
        {
            /* Request job result of SecFlash framework initialization */
            ecy_hsm_Csai_(ErrorT) csaiResult = ecy_hsm_Csai_(PollHandle(secFlashJob));

            /* If result is available */
            if (csaiResult != ecy_hsm_CSAI_(FC_PENDING))
            {
                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
                    /* Update actual position */
                    actualPos_ram_ui32 = actualPos_ram_ui32 + actualLength_ui32;
                    actualPos_rom_ui32 = actualPos_rom_ui32 + actualLength_ui32;

                    /* If not all data processed */
                    if (actualPos_rom_ui32 < (dataStartAddress_ui32 + dataLength_ui32))
                    {
                        /* Limit length for hashing to RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER value */
                        if (((dataStartAddress_ui32 + dataLength_ui32) - actualPos_rom_ui32) > RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER)
                        {
                            actualLength_ui32 = RBA_BLDRHSM_SECFLASH_ON_THE_FLY_BUFFER;
                        }
                        else
                        {
                            actualLength_ui32 = ((dataStartAddress_ui32 + dataLength_ui32) - actualPos_rom_ui32);
                        }

                        rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_PrepareBuffer;
						retValue = E_PENDING;
                    }
                    else
                    {
                        /* All data processed */
                        retValue = E_OK;
                    }
                }
                else
                {
                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* Signal calling function that another activation is required */
                retValue = E_PENDING;
            }

            break;
        }

        default:
        {
            retValue = E_NOT_OK;

            break;
        }
    }

    if (retValue != E_PENDING)
    {
        rba_BldrHsm_SecFlashUpdate_StateMachine_st = rba_BldrHsm_SecFlash_Init;
    }

    return retValue;
}

/**
 * This function does CSAI job handling for CSAI_SecFlash_Finish

 * KeyHandle need to be provided via rba_BldrHsm_SecFlash_GetKeyAndSignature.
 *
 * return value:
 * E_OK: Signature was verfied successfully.
 * E_NOT_OK: Failure occured.
 * E_PENDING: Processing not finished. Call again.
 */
Std_ReturnType rba_BldrHsm_SecFlashFinalize(RBA_BLDRHSM_KEY_ID_TYPE keyId, const uint8* signature_pu8, uint32 signatureLength_u32)
{
    static rba_BldrHsm_SecFlashFinalize_StateMachine_tst rba_BldrHsm_SecFlashFinalize_StateMachine_st = rba_BldrHsm_SecFlashFinalize_KeyHandling;

    Std_ReturnType retValue = E_NOT_OK;
    ecy_hsm_Csai_(ErrorT) csaiResult = ecy_hsm_CSAI_(ERR_FLAG_ERROR);

    static const uint8* secFlashSignature_pu8;
    static uint32 secFlashSignatureLength_u32;

    RBA_BLDRHSM_MEMMAP_START_BSS
    static uint32 pResultFlag_u32;      /* Variable will be written by HSM. Allow remap of value to hsm shared section, if required */
    static ecy_hsm_Csai_(KeyHandleT) keyHandle;   /* Variable will be written by HSM. Allow remap of value to hsm shared section, if required */
    RBA_BLDRHSM_MEMMAP_STOP_BSS

    switch (rba_BldrHsm_SecFlashFinalize_StateMachine_st)
    {
        case rba_BldrHsm_SecFlashFinalize_KeyHandling:
        {
            /* Init function specific static variables */
            pResultFlag_u32 = 0;
            keyHandle = ecy_hsm_CSAI_(INVALID_KEY_HANDLE_VALUE); /* Init value = required value for  HSM reprog */

            /* If HSM reprog detected, key and signature handling is done by HSM */
            #if (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)
                if (hsmReprogActive_b)
                {
                    rba_BldrHsm_SecFlashFinalize_StateMachine_st = rba_BldrHsm_SecFlashFinalize_Verify;
                    /* No external signature for HSM reprog required */
                    secFlashSignature_pu8 = NULL_PTR;
                    secFlashSignatureLength_u32 = 0;
                    retValue = E_PENDING;
                }
                else
            #endif
                {

            #if (RBA_BLDRHSM_SECBOOT == RBA_BLDRHSM_ENABLE)

                    /* Get active secflash session from session manager */
                    ecy_hsm_Csai_(SessionHandleT) session = rba_BldrHsm_GetSession(rba_BldrHsm_SessionType_RB);

                    /* If session was successfully opened (session handle is not invalid) */
                    if (session != ecy_hsm_CSAI_(INVALID_SESSION_HANDLE_VALUE))
                    {
                        /* Create key handle for ecy_hsm_Csai_SecFlash_Finalize */
                        retValue = rba_BldrHsm_Cfg_CreateKeyHandle(session, keyId, &keyHandle);

                        /* If key handle is available ... */
                        if (retValue == E_OK)
                        {
                            /* ... proceed with signature verification */
                            if((signature_pu8 != NULL_PTR) && (signatureLength_u32 != 0u))
                            {
                                secFlashSignature_pu8 = signature_pu8;
                                secFlashSignatureLength_u32 = signatureLength_u32;
                                rba_BldrHsm_SecFlashFinalize_StateMachine_st = rba_BldrHsm_SecFlashFinalize_Verify;
                                retValue = E_PENDING;
                            }
                            else
                            {
                                retValue = E_NOT_OK;
                            }
                        }
                    }
                    else
                    {
                        retValue = E_NOT_OK;
                    }
            #else
                    /* Secure boot feature is not activated.
                     * Bosch signature verification can be skipped.
                     * Provide positive result */
                    retValue = E_OK;
                    pResultFlag_u32 = 1u;
            #endif
                }

            break;
        }

        case rba_BldrHsm_SecFlashFinalize_Verify:
        {
            /* If signature is available  BOSCH signature for secure flash */
            if (ecy_hsm_Csai_(SecFlash_Finalize(secFlashJob, secFlashSignature_pu8, secFlashSignatureLength_u32, keyHandle, &pResultFlag_u32)) == ecy_hsm_CSAI_(SUCCESS))
            {
                rba_BldrHsm_SecFlashFinalize_StateMachine_st = rba_BldrHsm_SecFlashFinalize_PollHandle;
                retValue = E_PENDING;
            }
            else
            {
                /* HSM failure */
                retValue = E_NOT_OK;
            }

            break;
		}

        case rba_BldrHsm_SecFlashFinalize_PollHandle:
        {
            /* Request job result of signature verfication */
            csaiResult = ecy_hsm_Csai_(PollHandle(secFlashJob));

            /* If result is available */
            if (csaiResult != ecy_hsm_CSAI_(FC_PENDING))
            {
                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
                    retValue = E_OK;
                }
                else
                {
                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* Signal calling function that another activation is required */
                retValue = E_PENDING;
            }

            break;
		}

        default:
		{
            /* Unknown state */
            retValue = E_NOT_OK;

            break;
		}
    }

    if (retValue != E_PENDING)
    {
        /* Init state machine */
        rba_BldrHsm_SecFlashFinalize_StateMachine_st = rba_BldrHsm_SecFlashFinalize_KeyHandling;
    #if (RBA_BLDRHSM_HSMREPROG == RBA_BLDRHSM_ENABLE)
        hsmReprogActive_b = FALSE;
    #endif

    }

    return retValue;
}
#endif

#endif

#endif /* #if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE) */
