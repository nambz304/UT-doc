/******************************************************************************/
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/******************************************************************************/
#include "Std_Types.h"

#include "rba_BldrHsm.h"

#if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE)

#include ecy_hsm_(csai.h)
#include ecy_hsm_(csai_keys.h)

Std_ReturnType rba_BldrHsm_InjectPublicKey(ecy_hsm_Csai_(SessionHandleT) session, ecy_hsm_Csai_(KeyRefT)* keyRef, ecy_hsm_Csai_(KeyHandleT)* keyHandle)
{
    Std_ReturnType retValue = E_NOT_OK;

    static ecy_hsm_Csai_(JobHandleT) jobHandle = ecy_hsm_CSAI_(INVALID_JOB_HANDLE_VALUE);
    static boolean waitingForPollHandle_b = FALSE;

    if (waitingForPollHandle_b == FALSE)
    {
        /* Inject key and save result for next states */
        if (ecy_hsm_Csai_(InjectKey(session, ecy_hsm_CSAI_(PRIO_MEDIUM), keyRef, ecy_hsm_CSAI_(KEYPROP_IS_PUBLIC_KEY), keyHandle, &jobHandle)) == ecy_hsm_CSAI_(SUCCESS))
        {
            waitingForPollHandle_b = TRUE;
            retValue = E_PENDING;
        }
        else
        {
            retValue = E_NOT_OK;
        }
    }
    else 
    {
        /* Request job result of ecy_hsm_Csai_InjectKey */
        ecy_hsm_Csai_(ErrorT) csaiResult = ecy_hsm_Csai_(PollHandle(jobHandle));

        /* If job result is available, check result */
        if (csaiResult != ecy_hsm_CSAI_(FC_PENDING))
        {
            if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
            {
                retValue = E_OK;
            }
            else 
            {
                retValue = E_NOT_OK;
            }
        }
        else
        {
            retValue = E_PENDING;
        } 
    }

    if (retValue != E_PENDING)
    {
        waitingForPollHandle_b = FALSE;
        jobHandle = ecy_hsm_CSAI_(INVALID_JOB_HANDLE_VALUE);
    }

    return retValue;
}

#endif /* #if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE) */
