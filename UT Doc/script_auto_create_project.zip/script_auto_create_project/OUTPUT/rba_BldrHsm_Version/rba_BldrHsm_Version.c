/******************************************************************************/
/* Robert Bosch GmbH reserves all rights even in the event of industrial      */
/* property rights. We reserve all rights of disposal such as copying and     */
/* passing on to third parties.                                               */
/******************************************************************************/

#include "Std_Types.h"

#include "rba_BldrHsm.h"

#if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE)

#include ecy_hsm_(csai.h)
#include ecy_hsm_(csai_misc.h)

extern ecy_hsm_Csai_(SessionHandleT) gSession;
Std_ReturnType rba_BldrHsm_GetCoreVersion(rba_BldrHsm_VersionData_tst * versionData_st)
{
    static rba_BldrHsm_GetCoreVersion_StateMachine_tst rba_BldrHsm_GetCoreVersion_StateMachine_st = rba_BldrHsm_GetCoreVersion_Init ;

    ecy_hsm_Csai_(SessionHandleT) hSession = ecy_hsm_CSAI_(INVALID_SESSION_HANDLE_VALUE);
    static ecy_hsm_Csai_(JobHandleT) hJob = ecy_hsm_CSAI_(INVALID_JOB_HANDLE_VALUE);
    static ecy_hsm_Csai_(ErrorT) csaiResult = ecy_hsm_CSAI_(ERR_FLAG_ERROR);

    RBA_BLDRHSM_MEMMAP_START_BSS
    static ecy_hsm_Csai_(VersionDataT) versionDetected; /* Variable will be written by HSM. Allow remap of value to hsm shared section, if required */
    RBA_BLDRHSM_MEMMAP_STOP_BSS

    Std_ReturnType retValue = E_NOT_OK;

    switch (rba_BldrHsm_GetCoreVersion_StateMachine_st)
    {
        case rba_BldrHsm_GetCoreVersion_Init:

            /* Get active RB session from session manager */
            hSession = gSession; //rba_BldrHsm_GetSession(rba_BldrHsm_SessionType_OEM);

            /* Initialize version data */
            (*versionData_st).buildDay =0xFFFFFFFFu;
            (*versionData_st).buildMonth =  0xFFFFFFFFu;
            (*versionData_st).buildYear = 0xFFFFFFFFu;
            (*versionData_st).repoRevision = 0xFFFFFFFFu;
            (*versionData_st).interfaceVersion = 0xFFFFFFFFu;
            (*versionData_st).minimumInterfaceVersion = 0xFFFFFFFFu;
            (*versionData_st).softwareMajorVersion_u8 = 0xFFu;
            (*versionData_st).softwareMinorVersion_u8 = 0xFFu;
            (*versionData_st).softwareRevision_u8 = 0xFFu;


            if (hSession != ecy_hsm_CSAI_(INVALID_SESSION_HANDLE_VALUE))
            {
                /* Trigger version api and save result for next states */
                csaiResult = ecy_hsm_Csai_(GetCoreVersion(hSession, ecy_hsm_CSAI_(PRIO_BACKGROUND), &versionDetected, &hJob));
                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
                    /* Call succeeded. Operation is pending on HSM. Result needs to be polled via ecy_hsm_Csai_PollHandle */
                    rba_BldrHsm_GetCoreVersion_StateMachine_st = rba_BldrHsm_GetCoreVersion_PollHandle;

                    /* Signal calling function that another activation is required */
                    retValue = E_PENDING;
                }
                else
                {
                    /* HSM failure */
                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* Session couldn't be opened. No free ports available. Session handle will be invalid */
                retValue = E_NOT_OK;
            }
            break;

        case rba_BldrHsm_GetCoreVersion_PollHandle:

            /* Request job result of version api */
            csaiResult = ecy_hsm_Csai_(PollHandle(hJob));

            /* If job result is available */
            if (csaiResult != ecy_hsm_CSAI_(FC_PENDING))
            {
                /* Map final csai result to return value */
                if (csaiResult == ecy_hsm_CSAI_(SUCCESS))
                {
                    /* Copy detected version to output parameter structure */
                    (*versionData_st).compiler = versionDetected.compiler;
                    (*versionData_st).target = versionDetected.target;
                    (*versionData_st).buildType = versionDetected.buildType;
                    (*versionData_st).releaseStatus = versionDetected.releaseStatus;
                    (*versionData_st).buildDay = versionDetected.buildDay;
                    (*versionData_st).buildMonth =  versionDetected.buildMonth;
                    (*versionData_st).buildYear = versionDetected.buildYear;
                    (*versionData_st).repoRevision = versionDetected.repoRevision;
                    (*versionData_st).interfaceVersion = versionDetected.interfaceVersion;
                    (*versionData_st).minimumInterfaceVersion = versionDetected.minimumInterfaceVersion;
                    (*versionData_st).softwareMajorVersion_u8 = versionDetected.softwareMajorVersion;
                    (*versionData_st).softwareMinorVersion_u8 = versionDetected.softwareMinorVersion;
                    (*versionData_st).softwareRevision_u8 = versionDetected.softwareRevision;

                    retValue = E_OK;
                }
                else
                {
                    /* HSM failure */
                    retValue = E_NOT_OK;
                }
            }
            else
            {
                /* CSAI job is stll running. Call again */
                retValue = E_PENDING;
            }

            break;

        default:
            /* Unknown state */
            retValue = E_NOT_OK;

            break;
    }

    if (retValue != E_PENDING)
    {
        /* Init state machine for next run */
        rba_BldrHsm_GetCoreVersion_StateMachine_st = rba_BldrHsm_GetCoreVersion_Init;
    }

    return retValue;
}

#endif /* #if (RBA_BLDRHSM == RBA_BLDRHSM_ENABLE) */
