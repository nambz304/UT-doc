/* Stub of Rte_EcuM_Type.h
 * jov4abt - 20120828
 */

#ifndef RTE_H
#define RTE_H

#include <Std_Types.h>

#endif /* RTE_H */
