/*
 * Net_Global.h
 *
 *  Created on: Mar 5, 2015
 *      Author: dir1hc
 */

#ifndef NET_GLOBAL_H_
#define NET_GLOBAL_H_



#endif /* NET_GLOBAL_H_ */
