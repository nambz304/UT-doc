/*
 * HMI_Global_ref.h
 *
 *  Created on: Mar 5, 2015
 *      Author: dir1hc
 */

#ifndef HMI_GLOBAL_REF_H_
#define HMI_GLOBAL_REF_H_



#endif /* HMI_GLOBAL_REF_H_ */
