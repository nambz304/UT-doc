/*
 * DNCIF_RSC_CMA.h
 *
 *  Created on: May 5, 2015
 *      Author: prn1hc
 */

#ifndef DNCIF_RSC_CMA_H_
#define DNCIF_RSC_CMA_H_



#endif /* DNCIF_SSP_CMA_H_ */
